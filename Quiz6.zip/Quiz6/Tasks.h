//
//  Tasks.h
//  Quiz5
//
//  Created by Krystle on 3/14/14.
//  Copyright (c) 2014 Krystle Kidd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Tasks : NSObject{
   
}

@property (nonatomic) NSString *name;
@property (nonatomic) NSDate *dueDate;
@property (nonatomic) NSUInteger urgency;




@end
