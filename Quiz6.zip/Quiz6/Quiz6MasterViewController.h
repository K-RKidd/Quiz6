//
//  Quiz6MasterViewController.h
//  Quiz6
//
//  Created by Krystle on 3/28/14.
//  Copyright (c) 2014 Krystle Kidd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Tasks.h"
@interface Quiz6MasterViewController : UITableViewController

@property (nonatomic)Tasks *task;

@end
